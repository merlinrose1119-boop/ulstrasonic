# Ultrasonic Distance Dashboard

## Run
1. Install Node.js 16+ (https://nodejs.org)
2. In this folder:  `node server.js`
3. Open http://localhost:3000

## Test without ESP32
In a second terminal: `node send-test.js`

## Send data (anyone / any device)
POST JSON to `http://<YOUR-PC-IP>:3000/api/data`

    {
      "device_id": "ultrasonic-01",
      "distance_cm": 36.7,
      "status": "safe",
      "timestamp": "2026-11-25T10:21:00Z"
    }

Only `distance_cm` is required. The server prints your PC IP when it starts.
Sender and PC must be on the same WiFi/network (allow port 3000 in firewall).

curl example:
    curl -X POST http://localhost:3000/api/data -H "Content-Type: application/json" -d '{"device_id":"ultrasonic-01","distance_cm":36.7,"status":"safe"}'

## ESP32 (Arduino) snippet
    #include <WiFi.h>
    #include <HTTPClient.h>

    const char* ssid = "YOUR_WIFI";
    const char* pass = "YOUR_PASSWORD";
    const char* url  = "http://192.168.1.10:3000/api/data";  // your PC IP

    const int trigPin = 5, echoPin = 18;

    float readCm() {
      digitalWrite(trigPin, LOW);  delayMicroseconds(2);
      digitalWrite(trigPin, HIGH); delayMicroseconds(10);
      digitalWrite(trigPin, LOW);
      long t = pulseIn(echoPin, HIGH, 30000);
      return t * 0.0343 / 2;
    }

    void setup() {
      pinMode(trigPin, OUTPUT); pinMode(echoPin, INPUT);
      WiFi.begin(ssid, pass);
      while (WiFi.status() != WL_CONNECTED) delay(500);
    }

    void loop() {
      float d = readCm();
      HTTPClient http;
      http.begin(url);
      http.addHeader("Content-Type", "application/json");
      String body = "{\"device_id\":\"ultrasonic-01\",\"distance_cm\":" + String(d, 1) +
                    ",\"status\":\"" + (d < 20 ? "warning" : "safe") + "\"}";
      http.POST(body);
      http.end();
      delay(1000);
    }

## API
- POST /api/data      – send a reading
- GET  /api/latest    – latest reading (+ online flag)
- GET  /api/history   – last readings (?limit=60)
- GET  /api/devices   – known device ids
