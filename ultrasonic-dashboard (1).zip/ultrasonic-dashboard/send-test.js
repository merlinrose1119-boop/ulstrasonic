// Fake sensor: sends random readings every 1.5s so you can test without ESP32
const URL = process.argv[2] || "http://localhost:3000/api/data";
setInterval(async () => {
  const d = +(Math.random() * 180 + 5).toFixed(1);
  const body = { device_id: "ultrasonic-01", distance_cm: d, status: d < 20 ? "warning" : "safe", timestamp: new Date().toISOString() };
  try {
    await fetch(URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    console.log("sent", body.distance_cm);
  } catch (e) { console.log("failed:", e.message); }
}, 1500);
