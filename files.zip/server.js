// Ultrasonic Distance API + Dashboard server (no npm install needed, Node 18+)
// Run: node server.js   ->  http://localhost:3000
//
// Hardware (ESP32/Arduino) -> POST /api/distance   {"distance": 36.7, "device": "esp32-1"}
// Dashboard / other servers -> GET /api/distance/latest , GET /api/distance/history?limit=60
//
// Optional security: set API_KEY=yourSecret, then the hardware must send header  x-api-key: yourSecret

const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY || "";
const MAX_KEEP = 1000;
let readings = []; // { distance, device, at }

const json = (res, status, data) => {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",              // lets other servers/websites read the data
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-api-key",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(data));
};

const statusOf = (d) => (d < 15 ? "Danger" : d < 30 ? "Warning" : "Safe Distance");

function stats(list) {
  if (!list.length) return { min: null, max: null, average: null, count: 0 };
  const v = list.map((r) => r.distance);
  const sum = v.reduce((a, b) => a + b, 0);
  return {
    min: +Math.min(...v).toFixed(1),
    max: +Math.max(...v).toFixed(1),
    average: +(sum / v.length).toFixed(1),
    count: v.length,
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = "";
    req.on("data", (c) => { b += c; if (b.length > 1e5) { req.destroy(); reject(new Error("Body too large")); } });
    req.on("end", () => { try { resolve(b ? JSON.parse(b) : {}); } catch { reject(new Error("Invalid JSON")); } });
  });
}

const TYPES = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript" };

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === "OPTIONS") return json(res, 204, {});

  // 1) Hardware sends a reading
  if (req.method === "POST" && url.pathname === "/api/distance") {
    if (API_KEY && req.headers["x-api-key"] !== API_KEY) return json(res, 401, { error: "Invalid API key" });
    try {
      const body = await readBody(req);
      const distance = Number(body.distance);
      if (!Number.isFinite(distance) || distance < 0 || distance > 1000)
        return json(res, 400, { error: "distance must be a number between 0 and 1000 (cm)" });
      const item = { distance: +distance.toFixed(1), device: String(body.device || "sensor-1"), at: Date.now() };
      readings.push(item);
      if (readings.length > MAX_KEEP) readings = readings.slice(-MAX_KEEP);
      return json(res, 201, { success: true, data: item, status: statusOf(item.distance) });
    } catch (e) { return json(res, 400, { error: e.message }); }
  }

  // 2) Latest reading (receiver / other servers)
  if (req.method === "GET" && url.pathname === "/api/distance/latest") {
    const last = readings[readings.length - 1];
    if (!last) return json(res, 200, { distance: null, connected: false });
    return json(res, 200, { ...last, status: statusOf(last.distance), connected: Date.now() - last.at < 5000 });
  }

  // 3) History + min/max/average
  if (req.method === "GET" && url.pathname === "/api/distance/history") {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get("limit")) || 60, 1), MAX_KEEP);
    const list = readings.slice(-limit);
    const last = readings[readings.length - 1];
    return json(res, 200, {
      connected: !!last && Date.now() - last.at < 5000,
      ...stats(list),
      readings: list,
    });
  }

  if (req.method === "DELETE" && url.pathname === "/api/distance") {
    if (API_KEY && req.headers["x-api-key"] !== API_KEY) return json(res, 401, { error: "Invalid API key" });
    readings = [];
    return json(res, 200, { success: true });
  }

  // 4) Serve the dashboard (index.html in the same folder)
  if (req.method === "GET" && !url.pathname.startsWith("/api")) {
    const file = path.join(__dirname, url.pathname === "/" ? "index.html" : path.normalize(url.pathname.slice(1)));
    if (!file.startsWith(__dirname) || path.basename(file) === "server.js") return json(res, 403, { error: "Forbidden" });
    return fs.readFile(file, (err, data) => {
      if (err) return json(res, 404, { error: "Not found" });
      res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream" });
      res.end(data);
    });
  }

  json(res, 404, { error: "Not found" });
}).listen(PORT, () => console.log(`Ultrasonic API + dashboard running at http://localhost:${PORT}`));
