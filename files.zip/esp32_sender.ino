// ESP32 + HC-SR04 -> sends distance (cm) as JSON to the API every second
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";

// Local test : "http://192.168.1.5:3000/api/distance"   (laptop IP, same WiFi)
// Hosted     : "https://your-app.onrender.com/api/distance"
const char* SERVER_URL = "http://192.168.1.5:3000/api/distance";
const char* API_KEY    = "";            // fill only if you set API_KEY on the server
const char* DEVICE     = "esp32-1";

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;                // use a voltage divider (5V echo -> 3.3V) on ESP32

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long us = pulseIn(ECHO_PIN, HIGH, 30000);   // 30 ms timeout
  if (us == 0) return -1;                      // no echo
  return us * 0.0343 / 2.0;
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nWiFi connected: " + WiFi.localIP().toString());
}

void loop() {
  float d = readDistanceCm();
  if (d > 0 && WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    WiFiClientSecure secure;
    if (String(SERVER_URL).startsWith("https")) { secure.setInsecure(); http.begin(secure, SERVER_URL); }
    else                                         { http.begin(SERVER_URL); }
    http.addHeader("Content-Type", "application/json");
    if (strlen(API_KEY)) http.addHeader("x-api-key", API_KEY);
    String body = "{\"distance\":" + String(d, 1) + ",\"device\":\"" + DEVICE + "\"}";
    int code = http.POST(body);
    Serial.printf("Sent %.1f cm -> HTTP %d\n", d, code);
    http.end();
  }
  delay(1000);
}
