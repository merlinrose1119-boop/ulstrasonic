// Ultrasonic Distance Dashboard - zero-dependency Node.js server
// Run: node server.js   (needs Node 16+)
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");

const PORT = process.env.PORT || 3000;
const MAX_HISTORY = 500;
const OFFLINE_AFTER_MS = 5000;

// device_id -> { latest, history[] }
const devices = {};

function send(res, code, body, type = "application/json") {
  res.writeHead(code, {
    "Content-Type": type,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Cache-Control": "no-store",
  });
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

function pickDevice(id) {
  if (id && devices[id]) return devices[id];
  // default: most recently updated device
  let best = null;
  for (const d of Object.values(devices)) {
    if (!best || d.latest.receivedAt > best.latest.receivedAt) best = d;
  }
  return best;
}

function withAge(latest) {
  const ageMs = Date.now() - latest.receivedAt;
  return { ...latest, ageMs, online: ageMs < OFFLINE_AFTER_MS };
}

function handleApi(req, res, url) {
  if (req.method === "OPTIONS") return send(res, 204, "");

  if (url.pathname === "/api/data" && req.method === "POST") {
    let raw = "";
    req.on("data", (c) => {
      raw += c;
      if (raw.length > 10000) req.destroy();
    });
    req.on("end", () => {
      let data;
      try { data = JSON.parse(raw); } catch { return send(res, 400, { ok: false, error: "Invalid JSON" }); }
      const distance = Number(data.distance_cm);
      if (!Number.isFinite(distance)) return send(res, 400, { ok: false, error: "distance_cm must be a number" });

      const id = String(data.device_id || "device-1");
      const entry = {
        device_id: id,
        distance_cm: distance,
        status: String(data.status || (distance < 20 ? "warning" : "safe")),
        timestamp: data.timestamp || new Date().toISOString(),
        receivedAt: Date.now(),
      };
      if (!devices[id]) devices[id] = { latest: entry, history: [] };
      devices[id].latest = entry;
      devices[id].history.push(entry);
      if (devices[id].history.length > MAX_HISTORY) devices[id].history.shift();

      console.log(`[${new Date().toLocaleTimeString()}] ${id}: ${distance} cm (${entry.status})`);
      send(res, 200, { ok: true });
    });
    return;
  }

  if (url.pathname === "/api/latest" && req.method === "GET") {
    const d = pickDevice(url.searchParams.get("device"));
    return send(res, 200, d ? withAge(d.latest) : { empty: true });
  }

  if (url.pathname === "/api/history" && req.method === "GET") {
    const d = pickDevice(url.searchParams.get("device"));
    const limit = Math.min(Number(url.searchParams.get("limit")) || 60, MAX_HISTORY);
    return send(res, 200, d ? d.history.slice(-limit) : []);
  }

  if (url.pathname === "/api/devices" && req.method === "GET") {
    return send(res, 200, Object.keys(devices));
  }

  send(res, 404, { error: "Not found" });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname.startsWith("/api/")) return handleApi(req, res, url);

  const file = url.pathname === "/" ? "/index.html" : url.pathname;
  const full = path.join(__dirname, "public", path.normalize(file));
  if (!full.startsWith(path.join(__dirname, "public"))) return send(res, 403, "Forbidden", "text/plain");
  fs.readFile(full, (err, buf) => {
    if (err) return send(res, 404, "Not found", "text/plain");
    send(res, 200, buf, full.endsWith(".html") ? "text/html; charset=utf-8" : "application/octet-stream");
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("\nUltrasonic Dashboard running!\n");
  console.log(`  Open dashboard : http://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces()))
    for (const i of list)
      if (i.family === "IPv4" && !i.internal) {
        console.log(`  Same WiFi/LAN  : http://${i.address}:${PORT}`);
        console.log(`  ESP32 POST URL : http://${i.address}:${PORT}/api/data`);
      }
  console.log("");
});
