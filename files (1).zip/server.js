// Sample JSON API: send data from one user to another.
// Run:  node server.js     (needs Node.js 18+, no npm install required)
// Server starts at http://localhost:3000 (portfolio website + API)
//
// Endpoints
//   POST /api/send            body: { "from": "merlin", "to": "arun", "message": "Hello" }
//   GET  /api/messages?user=arun      -> messages received by arun
//   GET  /api/data            -> all messages (for the "Refresh Data" button)
//   DELETE /api/data          -> clear everything
//
// Test with curl:
//   curl -X POST http://localhost:3000/api/send \
//        -H "Content-Type: application/json" \
//        -d '{"from":"merlin","to":"arun","message":"Hi Arun!"}'
//   curl "http://localhost:3000/api/messages?user=arun"

const http = require("http");
const { URL } = require("url");
const fs = require("fs");
const path = require("path");
// Uses the "public" folder if it exists, otherwise the same folder as server.js
const PUBLIC = fs.existsSync(path.join(__dirname, "public")) ? path.join(__dirname, "public") : __dirname;
const TYPES = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml" };

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY || ""; // optional: protects POST /api/distance
let readings = []; // ultrasonic readings
const distStatus = (d) => (d < 15 ? "Danger" : d < 30 ? "Warning" : "Safe Distance");
let messages = [];   // in-memory store (resets when the server restarts)
let nextId = 1;

function send(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    // CORS so your website/dashboard can call this API from the browser
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-api-key",
  });
  res.end(JSON.stringify(data, null, 2));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1e6) { req.destroy(); reject(new Error("Body too large")); }
    });
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error("Invalid JSON")); }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "OPTIONS") return send(res, 204, {});

  // Send data to another user
  if (req.method === "POST" && url.pathname === "/api/send") {
    try {
      const { from, to, message } = await readBody(req);
      if (!from || !to || !message) {
        return send(res, 400, { error: "from, to and message are required" });
      }
      const item = {
        id: nextId++,
        from: String(from).trim(),
        to: String(to).trim(),
        message: String(message).trim(),
        sentAt: new Date().toISOString(),
      };
      messages.push(item);
      return send(res, 201, { success: true, data: item });
    } catch (err) {
      return send(res, 400, { error: err.message });
    }
  }

  // Get messages received by one user
  if (req.method === "GET" && url.pathname === "/api/messages") {
    const user = (url.searchParams.get("user") || "").trim().toLowerCase();
    if (!user) return send(res, 400, { error: "user query parameter is required" });
    const inbox = messages.filter((m) => m.to.toLowerCase() === user);
    return send(res, 200, { user, count: inbox.length, messages: inbox });
  }

  // Get all data
  if (req.method === "GET" && url.pathname === "/api/data") {
    return send(res, 200, { count: messages.length, messages });
  }

  // Clear all data
  if (req.method === "DELETE" && url.pathname === "/api/data") {
    messages = [];
    return send(res, 200, { success: true });
  }

  // ---------- Ultrasonic sensor API ----------
  // Hardware: POST /api/distance {"distance": 36.7, "device": "esp32-1"}
  // Receivers: GET /api/distance/latest , GET /api/distance/history?limit=60
  if (req.method === "POST" && url.pathname === "/api/distance") {
    if (API_KEY && req.headers["x-api-key"] !== API_KEY) return send(res, 401, { error: "Invalid API key" });
    try {
      const body = await readBody(req);
      const distance = Number(body.distance);
      if (!Number.isFinite(distance) || distance < 0 || distance > 1000)
        return send(res, 400, { error: "distance must be a number between 0 and 1000 (cm)" });
      const item = { distance: +distance.toFixed(1), device: String(body.device || "sensor-1"), at: Date.now() };
      readings.push(item);
      if (readings.length > 1000) readings = readings.slice(-1000);
      return send(res, 201, { success: true, data: item, status: distStatus(item.distance) });
    } catch (e) { return send(res, 400, { error: e.message }); }
  }
  if (req.method === "GET" && url.pathname === "/api/distance/latest") {
    const last = readings[readings.length - 1];
    if (!last) return send(res, 200, { distance: null, connected: false });
    return send(res, 200, { ...last, status: distStatus(last.distance), connected: Date.now() - last.at < 5000 });
  }
  if (req.method === "GET" && url.pathname === "/api/distance/history") {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get("limit")) || 60, 1), 1000);
    const list = readings.slice(-limit), v = list.map((r) => r.distance), last = readings[readings.length - 1];
    return send(res, 200, {
      connected: !!last && Date.now() - last.at < 5000,
      min: v.length ? +Math.min(...v).toFixed(1) : null,
      max: v.length ? +Math.max(...v).toFixed(1) : null,
      average: v.length ? +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(1) : null,
      count: v.length, readings: list,
    });
  }

  // Serve the portfolio website from /public
  if (req.method === "GET" && !url.pathname.startsWith("/api")) {
    const rel = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
    const file = path.join(PUBLIC, path.normalize(rel));
    if (!file.startsWith(PUBLIC) || path.basename(file) === "server.js") return send(res, 403, { error: "Forbidden" });
    return fs.readFile(file, (err, data) => {
      if (err) return send(res, 404, { error: "Not found" });
      res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream" });
      res.end(data);
    });
  }

  send(res, 404, { error: "Not found" });
});

server.listen(PORT, () => console.log(`API running at http://localhost:${PORT}`));
